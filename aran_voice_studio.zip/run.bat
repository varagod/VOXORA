@echo off
setlocal
title Aran Voice Studio

REM Always run from this folder so the local virtual environment is used.
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] The project's virtual environment was not found.
    echo Expected: %CD%\.venv\Scripts\python.exe
    echo Please do not run the old installer. Contact support with this message.
    pause
    exit /b 1
)

if not exist "app.py" (
    echo [ERROR] app.py was not found in:
    echo %CD%
    pause
    exit /b 1
)

REM Bypass any configured HTTP proxy for local Gradio health checks only.
set "NO_PROXY=127.0.0.1,localhost,::1"
set "no_proxy=127.0.0.1,localhost,::1"

echo Starting Aran Voice Studio with the project's Python environment...
echo Local address: http://127.0.0.1:7860
echo Keep this window open while using the studio.
echo To stop the studio, press Ctrl+C in this window.
echo.

".venv\Scripts\python.exe" app.py

echo.
echo Aran Voice Studio has stopped.
pause
endlocal
