from __future__ import annotations
import json, os, shutil, tempfile, traceback
from pathlib import Path
import gradio as gr
import numpy as np
import soundfile as sf

from audio_fx import process_radio


ROOT = Path(__file__).resolve().parent
VOICE_DIR = ROOT / "voices"
OUT_DIR = ROOT / "outputs"
VOICE_DIR.mkdir(exist_ok=True)
OUT_DIR.mkdir(exist_ok=True)
MODEL_NAME = "MohammadJRanjbar/parsvoice-xtts-v2"
MODEL = None
MODEL_LOAD_ERROR = None
MODEL_LANG = None


def get_device():
    try:
        import torch
        if torch.cuda.is_available():
            return f"GPU: {torch.cuda.get_device_name(0)} | CUDA {torch.version.cuda}"
        return "GPU شناسایی نشد؛ اجرا روی CPU انجام می‌شود."
    except Exception:
        return "وضعیت GPU نامشخص است؛ ابتدا نصب را کامل کنید."


def load_model(language):
    global MODEL, MODEL_LOAD_ERROR, MODEL_LANG
    lang_code = "fa" if language == "فارسی" else "en"
    selected_model = MODEL_NAME if lang_code == "fa" else "tts_models/multilingual/multi-dataset/xtts_v2"
    if MODEL is not None and MODEL_LANG == lang_code:
        return f"✅ مدل {language} از قبل در حافظه آماده است.\n" + get_device()
    try:
        from TTS.api import TTS
        import torch
        if MODEL is not None and MODEL_LANG != lang_code:
            del MODEL
            MODEL = None
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        use_gpu = torch.cuda.is_available()
        MODEL = TTS(selected_model, gpu=use_gpu)
        MODEL_LANG = lang_code
        MODEL_LOAD_ERROR = None
        return f"✅ مدل {language} آماده شد ({selected_model}).\n" + get_device()
    except Exception as e:
        MODEL_LOAD_ERROR = traceback.format_exc()
        return "❌ بارگذاری مدل ناموفق بود:\n" + str(e) + "\n\nاگر مدل Hugging Face محدودیت دسترسی دارد، ابتدا در سایت HF وارد شوید و شرایط مدل را قبول کنید؛ سپس HF_TOKEN را در فایل .env قرار دهید."


def profile_names():
    names = []
    for f in VOICE_DIR.glob("*/voice.json"):
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            names.append(d.get("name", f.parent.name))
        except Exception:
            names.append(f.parent.name)
    return sorted(set(names))


def profile_path(name):
    for f in VOICE_DIR.glob("*/voice.json"):
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            if d.get("name") == name:
                return f.parent / d.get("reference", "reference.wav")
        except Exception:
            pass
    return None


def refresh_voices():
    return gr.update(choices=["— بدون پروفایل —"] + profile_names(), value="— بدون پروفایل —")


def save_voice(ref_file, name):
    if not ref_file:
        return "⚠️ اول یک نمونه صدا وارد کنید.", refresh_voices()
    name = (name or "").strip()
    if not name:
        return "⚠️ برای پروفایل یک نام وارد کنید.", refresh_voices()
    safe = "".join(ch for ch in name if ch.isalnum() or ch in "-_ ").strip().replace(" ", "_")[:48]
    if not safe:
        safe = "voice_profile"
    folder = VOICE_DIR / safe
    folder.mkdir(parents=True, exist_ok=True)
    source = Path(ref_file)
    ext = source.suffix.lower()
    if ext not in [".wav", ".mp3", ".flac", ".ogg", ".m4a"]:
        ext = ".wav"
    shutil.copy2(source, folder / f"reference{ext}")
    meta = {"name": name, "reference": f"reference{ext}", "created_by": "Aran Voice Studio"}
    (folder / "voice.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return f"✅ پروفایل «{name}» ذخیره شد.", refresh_voices()



def get_reference(upload, selected):
    if selected and selected != "— بدون پروفایل —":
        p = profile_path(selected)
        if p and p.exists():
            return str(p)
    if upload:
        return upload
    return None



def generate(text, ref_upload, selected_voice, language, speed, radio_enabled, preset, strength, noise, saturation, low_cut, high_cut, compressor, export_format):
    wanted_lang = "fa" if language == "فارسی" else "en"
    if MODEL is None or MODEL_LANG != wanted_lang:
        return None, None, f"⛔ مدل {language} بارگذاری نشده یا زبان مدل با انتخاب شما متفاوت است. «Load Model» را بزنید."
    text = (text or "").strip()
    if not text:
        return None, None, "⛔ متن خالی است."
    reference = get_reference(ref_upload, selected_voice)
    if not reference:
        return None, None, "⛔ نمونه صدای مرجع را آپلود کنید یا یک پروفایل انتخاب کنید."
    try:
        temp_wav = OUT_DIR / "temp_speech.wav"
        # XTTS API uses speed; clone from reference clip. ParsVoice is Persian fine-tune.
        MODEL.tts_to_file(text=text, speaker_wav=reference, language=wanted_lang, file_path=str(temp_wav), speed=float(speed))
        raw, sr = sf.read(str(temp_wav), dtype="float32", always_2d=True)
        processed = process_radio(raw, sr, enabled=radio_enabled, preset=preset, strength=strength,
                                noise=noise, saturation=saturation, low_cut=low_cut,
                                high_cut=high_cut, compressor=compressor)
        stamp = __import__("datetime").datetime.now().strftime("%Y%m%d_%H%M%S")
        base = OUT_DIR / f"Aran_{stamp}"
        wav_out = str(base.with_suffix(".wav"))
        sf.write(wav_out, processed, sr, subtype="PCM_16")
        mp3_out = None
        if export_format in ["MP3", "WAV + MP3"]:
            try:
                from pydub import AudioSegment
                segment = AudioSegment.from_wav(wav_out)
                mp3_out = str(base.with_suffix(".mp3"))
                segment.export(mp3_out, format="mp3", bitrate="192k")
            except Exception as mp3err:
                return wav_out, wav_out, "⚠️ WAV ساخته شد؛ تبدیل MP3 به FFmpeg نیاز دارد. خطا: " + str(mp3err)
        msg = "✅ خروجی آماده شد."
        if radio_enabled:
            msg += f" افکت «{preset}» با شدت {strength}% اعمال شد."
        return wav_out, mp3_out or wav_out, msg
    except Exception as e:
        return None, None, "❌ تولید صدا ناموفق بود:\n" + str(e) + "\n\n" + traceback.format_exc(limit=2)



def preview_radio(ref_upload, radio_enabled, preset, strength, noise, saturation, low_cut, high_cut, compressor):
    if not ref_upload:
        return None, "⚠️ برای تست افکت، نمونه صوتی را آپلود کنید."
    try:
        try:
            audio, sr = sf.read(ref_upload, dtype="float32", always_2d=True)
        except Exception:
            from pydub import AudioSegment
            clip = AudioSegment.from_file(ref_upload)
            clip = clip.set_channels(1).set_frame_rate(24000)
            sr = clip.frame_rate
            audio = np.asarray(clip.get_array_of_samples(), dtype=np.float32).reshape(-1, 1)
            audio /= max(abs(clip.max_possible_amplitude), 1)
        processed = process_radio(audio, sr, enabled=radio_enabled, preset=preset, strength=strength,
                                noise=noise, saturation=saturation, low_cut=low_cut,
                                high_cut=high_cut, compressor=compressor)
        path = str(OUT_DIR / "Radio_Effect_Preview.wav")
        sf.write(path, processed, sr, subtype="PCM_16")
        return path, "🎚️ افکت روی نمونه مرجع اعمال شد. تنظیمات را تغییر دهید و دوباره Preview بگیرید."
    except Exception as e:
        return None, "❌ پیش‌نمایش افکت ناموفق: " + str(e)


def preset_values(choice):
    table = {
        "Classic radio": (280, 3600, 72, 8, 25),
        "Walkie-talkie": (420, 2900, 82, 22, 42),
        "Clean broadcast": (140, 5200, 42, 2, 12),
        "Old AM radio": (350, 3000, 78, 30, 50),
    }
    low, high, mix, n, sat = table.get(choice, table["Classic radio"])
    return low, high, mix, n, sat



def clear_text():
    return ""



with gr.Blocks(title="Aran Voice Studio", theme=gr.themes.Soft(), css="""ody { direction: rtl; }
.gradio-container { max-width: 1440px !important; }
#header { text-align: right; padding: 10px 4px 0; }
#header h1 { letter-spacing: -1px; }
#subhead { color: var(--body-text-color-subdued); }
#maintext textarea { direction: rtl; text-align: right; font-size: 17px; line-height: 1.8; }
.panel { border: 1px solid var(--border-color-primary); border-radius: 16px; padding: 14px; }
footer { display:none !important; }
""") as demo:
    gr.Markdown("# 🎙️ Aran Voice Studio\n**استودیوی تولید صدا با کلون صوتی محلی + افکت رادیویی**", elem_id="header")
    gr.Markdown("ساخت نریشن برای Social Awareness Advocate — پردازش روی سیستم شما؛ بدون نیاز به کردیت ElevenLabs", elem_id="subhead")
    with gr.Row(equal_height=False):
        with gr.Column(scale=7):
            with gr.Group(elem_classes=["panel"]):
                gr.Markdown("### ✍️ متن نریشن")
                text_in = gr.Textbox(label="متن", lines=10, placeholder="متن انگلیسی یا فارسی را اینجا وارد کنید…", elem_id="maintext")
                with gr.Row():
                    speed = gr.Slider(0.75, 1.25, value=1.0, step=0.01, label="سرعت گفتار")
                    export_format = gr.Radio(["WAV", "MP3", "WAV + MP3"], value="WAV + MP3", label="فرمت خروجی")
            with gr.Group(elem_classes=["panel"]):
                gr.Markdown("### 🎧 خروجی")
                audio_out = gr.Audio(label="پخش خروجی", type="filepath")
                file_out = gr.File(label="دانلود فایل خروجی")
                status = gr.Markdown("مدل هنوز Load نشده است.")
                with gr.Row():
                    load_btn = gr.Button("⬇️ Load Model / دانلود و بارگذاری", variant="secondary")
                    gen_btn = gr.Button("✨ Generate Speech", variant="primary")
                    clear_btn = gr.Button("پاک کردن متن")
        with gr.Column(scale=5):
            with gr.Group(elem_classes=["panel"]):
                gr.Markdown("### 🗣️ Voice Reference")
                ref_audio = gr.Audio(label="نمونه صدای مرجع (حدود 6 تا 15 ثانیه، تمیز)", type="filepath", sources=["upload", "microphone"])
                saved_voice = gr.Dropdown(label="پروفایل‌های ذخیره‌شده", choices=["— بدون پروفایل —"] + profile_names(), value="— بدون پروفایل —")
                with gr.Row():
                    profile_name = gr.Textbox(label="نام پروفایل جدید", placeholder="مثلاً Aran - Parsi", scale=3)
                    save_btn = gr.Button("💾 ذخیره نمونه", scale=1)
                save_status = gr.Markdown()
                gr.Markdown("### ⚙️ تنظیمات مدل")
                language = gr.Dropdown(["English", "فارسی"], value="English", label="زبان تولید")
                gr.Markdown(f"**مدل فارسی:** `{MODEL_NAME}`\n\n**مدل انگلیسی:** `tts_models/multilingual/multi-dataset/xtts_v2` — مدل به‌صورت محلی دانلود و اجرا می‌شود.")
                device_label = gr.Markdown(get_device())
            with gr.Group(elem_classes=["panel"]):
                gr.Markdown("### 📻 Radio Effect")
                radio_enabled = gr.Checkbox(label="فعال کردن افکت رادیویی", value=True)
                preset = gr.Dropdown(["Classic radio", "Walkie-talkie", "Clean broadcast", "Old AM radio"], value="Classic radio", label="Preset")
                strength = gr.Slider(0, 100, value=72, step=1, label="شدت افکت / Mix")
                noise = gr.Slider(0, 100, value=8, step=1, label="Static / نویز رادیویی")
                saturation = gr.Slider(0, 100, value=25, step=1, label="Radio warmth / Saturation")
                with gr.Accordion("تنظیمات حرفه‌ای فیلتر", open=False):
                    low_cut = gr.Slider(80, 1000, value=280, step=10, label="Low-cut (Hz)")
                    high_cut = gr.Slider(1200, 9000, value=3600, step=50, label="High-cut (Hz)")
                    compressor = gr.Slider(0, 100, value=55, step=1, label="Compression")
                preview_fx_btn = gr.Button("🔊 Preview Radio Effect on Reference")
                preview_fx_audio = gr.Audio(label="Radio Effect Preview", type="filepath")
                preview_fx_status = gr.Markdown()
    preset.change(preset_values, inputs=[preset], outputs=[low_cut, high_cut, strength, noise, saturation])
    load_btn.click(load_model, inputs=[language], outputs=[status])
    save_btn.click(save_voice, inputs=[ref_audio, profile_name], outputs=[save_status, saved_voice])
    preview_fx_btn.click(preview_radio, inputs=[ref_audio, radio_enabled, preset, strength, noise, saturation, low_cut, high_cut, compressor], outputs=[preview_fx_audio, preview_fx_status])
    gen_btn.click(generate, inputs=[text_in, ref_audio, saved_voice, language, speed, radio_enabled, preset, strength, noise, saturation, low_cut, high_cut, compressor, export_format], outputs=[audio_out, file_out, status])
    clear_btn.click(clear_text, outputs=[text_in])
    demo.load(lambda: get_device(), outputs=[device_label])

if __name__ == "__main__":
    demo.queue(max_size=10).launch(server_name="127.0.0.1", server_port=7860, inbrowser=True)
