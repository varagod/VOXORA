from __future__ import annotations
import numpy as np
from scipy.signal import butter, sosfiltfilt


def _safe_filter(audio: np.ndarray, sr: int, low: float | None, high: float | None):
    nyq = sr / 2
    low = max(20.0, float(low or 0))
    high = min(float(high or nyq - 100), nyq - 50)
    if low >= high:
        return audio
    if low > 20 and high < nyq - 50:
        sos = butter(4, [low / nyq, high / nyq], btype="bandpass", output="sos")
    elif low > 20:
        sos = butter(4, low / nyq, btype="highpass", output="sos")
    else:
        sos = butter(4, high / nyq, btype="lowpass", output="sos")
    return sosfiltfilt(sos, audio, axis=0)


def _compress(audio: np.ndarray, threshold_db: float = -18, ratio: float = 3.0):
    peak = np.maximum(np.abs(audio), 1e-7)
    db = 20 * np.log10(peak)
    over = np.maximum(db - threshold_db, 0)
    gain_db = -over * (1 - 1 / max(ratio, 1))
    gain = 10 ** (gain_db / 20)
    return audio * gain


def _soft_clip(audio: np.ndarray, drive: float):
    if drive <= 0:
        return audio
    x = audio * (1 + 6 * drive)
    return np.tanh(x) / np.tanh(1 + 6 * drive)


def process_radio(audio: np.ndarray, sr: int, enabled: bool = True, preset: str = "Classic radio",
                 strength: float = 65, noise: float = 0, saturation: float = 20,
                 low_cut: int = 280, high_cut: int = 3600, compressor: float = 55,
                 stereo: bool = True) -> np.ndarray:
    """Apply a controllable radio/broadcast chain to float audio in [-1, 1]."""
    if audio.ndim == 1:
        audio = audio[:, None]
    x = audio.astype(np.float32, copy=True)
    if not enabled:
        return np.clip(x, -1, 1)
    amt = float(np.clip(strength, 0, 100)) / 100
    preset_defaults = {
        "Classic radio": (280, 3600, 0.10, 0.18),
        "Walkie-talkie": (420, 2900, 0.18, 0.32),
        "Clean broadcast": (140, 5200, 0.03, 0.10),
        "Old AM radio": (350, 3000, 0.25, 0.40),
    }
    p_low, p_high, p_sat, p_noise = preset_defaults.get(preset, preset_defaults["Classic radio"])
    low = low_cut if low_cut is not None else p_low
    high = high_cut if high_cut is not None else p_high
    # User cutoffs blend from preset toward chosen values based on radio amount.
    x = _safe_filter(x, sr, low, high)
    comp_amt = np.clip(compressor / 100, 0, 1)
    if comp_amt:
        compressed = _compress(x, threshold_db=-22 + 8 * comp_amt, ratio=1.8 + 5 * comp_amt)
        x = x * (1 - comp_amt) + compressed * comp_amt
    sat_amt = np.clip(saturation / 100, 0, 1) * (0.05 + p_sat)
    x = x * (1 - sat_amt) + _soft_clip(x, sat_amt) * sat_amt
    if noise > 0:
        noise_amt = float(noise) / 100 * (0.003 + p_noise * 0.03)
        rng = np.random.default_rng()
        n = rng.normal(0, noise_amt, size=x.shape).astype(np.float32)
        # Slightly band-limit static too.
        n = _safe_filter(n, sr, max(120, low * 0.5), min(high * 1.2, sr / 2 - 100))
        x = x + n
    # Wet/dry blend gives a quick way to dial the radio effect down.
    x = audio.astype(np.float32) * (1 - amt) + x * amt
    if not stereo and x.shape[1] > 1:
        x = np.mean(x, axis=1, keepdims=True)
    # peak normalization is intentionally conservative; no aggressive loudness jump
    peak = np.max(np.abs(x)) if x.size else 0
    if peak > 0.98:
        x = x * (0.98 / peak)
    return np.clip(x, -1, 1)
