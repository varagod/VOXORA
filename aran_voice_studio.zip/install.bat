@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Aran Voice Studio - Setup

echo ===============================================
echo       Aran Voice Studio - Setup Wizard
echo ===============================================
where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher was not found.
  echo Install Python 3.11 x64 and enable the Python Launcher.
  echo https://www.python.org/downloads/release/python-3119/
  pause
  exit /b 1
)

py -3.11 --version
if errorlevel 1 (
  echo.
  echo Python 3.11 x64 was not found.
  echo Install it from:
  echo https://www.python.org/downloads/release/python-3119/
  pause
  exit /b 1
)

REM Rebuild the venv because the previous setup may have created it with Python 3.10.
if exist .venv (
  echo Removing the old virtual environment...
  rmdir /s /q .venv
)
echo Creating Python 3.11 virtual environment...
py -3.11 -m venv .venv
if errorlevel 1 goto :fail

call .venv\Scripts\activate.bat
if errorlevel 1 goto :fail

echo Updating pip tooling with a Torch-compatible setuptools version...
python -m pip install --upgrade pip wheel "setuptools<82"
if errorlevel 1 goto :fail

echo Installing PyTorch CUDA build (NVIDIA GPU)...
python -m pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128
if errorlevel 1 (
  echo CUDA build failed. Trying standard PyTorch installation...
  python -m pip install torch torchvision torchaudio
  if errorlevel 1 goto :fail
)

echo Installing application dependencies...
python -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo Checking Python and PyTorch...
python -c "import sys, torch, numpy; print('Python:', sys.version.split()[0]); print('PyTorch:', torch.__version__); print('CUDA available:', torch.cuda.is_available()); print('NumPy:', numpy.__version__)"
echo.
echo Setup complete. Run run.bat to launch Aran Voice Studio.
pause
exit /b 0

:fail
echo.
echo Installation failed. Please copy the complete error text and send it to ChatGPT.
pause
exit /b 1
