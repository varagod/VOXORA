@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Aran Voice Studio - Safe Resume Installer

cd /d "%~dp0"

echo ===============================================
echo   Aran Voice Studio - SAFE RESUME INSTALLER
echo ===============================================
echo.
echo This script DOES NOT delete .venv and DOES NOT reinstall PyTorch.
echo It will reuse the existing Python 3.11 environment and installed Torch.
echo.

if not exist "requirements.txt" (
    echo ERROR: requirements.txt was not found.
    echo Put this BAT file in the main Aran Voice Studio folder,
    echo beside app.py and requirements.txt.
    goto :FAILED
)

if not exist ".venv\Scripts\python.exe" (
    echo ERROR: Existing .venv was not found.
    echo To protect your downloads, this script will not create or replace it.
    goto :FAILED
)

set "PY=%CD%\.venv\Scripts\python.exe"

"%PY%" -c "import sys; print('Environment:', sys.version); assert sys.version_info[:2] == (3,11), 'This environment is not Python 3.11'"
if errorlevel 1 goto :FAILED

echo.
echo Checking the already-installed PyTorch. No PyTorch download will be started...
"%PY%" -c "from importlib.metadata import version; v=version('torch'); print('Installed Torch package:', v); assert v == '2.11.0+cu128', 'Unexpected Torch version; stopping to protect the current setup'"
if errorlevel 1 (
    echo ERROR: PyTorch could not be verified. No reinstall was attempted.
    goto :FAILED
)

echo.
echo Locating the Microsoft C++ compiler...
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
    echo ERROR: Visual Studio Installer vswhere.exe was not found.
    echo Check that the C++ Build Tools installation completed.
    goto :FAILED
)

set "VSINSTALL="
for /f "usebackq delims=" %%I in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSINSTALL=%%I"

if not defined VSINSTALL (
    echo ERROR: The MSVC x64/x86 C++ toolset was not detected.
    echo In Visual Studio Installer, add the workload:
    echo Desktop development with C++
    goto :FAILED
)

set "VCVARS=%VSINSTALL%\VC\Auxiliary\Build\vcvars64.bat"
if not exist "%VCVARS%" (
    echo ERROR: vcvars64.bat was not found in the detected Visual Studio installation.
    goto :FAILED
)

call "%VCVARS%" >nul
if errorlevel 1 goto :FAILED

where cl.exe
if errorlevel 1 (
    echo ERROR: MSVC compiler cl.exe could not be loaded.
    goto :FAILED
)

echo.
echo Checking setuptools compatibility...
"%PY%" -c "import setuptools; print('setuptools:', setuptools.__version__); from packaging.version import Version; assert Version(setuptools.__version__) < Version('82'), 'setuptools must be below 82'" >nul 2>&1
if errorlevel 1 (
    echo Installing compatible setuptools. This is a small download if not cached...
    "%PY%" -m pip install "setuptools<82"
    if errorlevel 1 goto :FAILED
)

set "CONSTRAINTS=%TEMP%\aran_voice_constraints_%RANDOM%.txt"
> "%CONSTRAINTS%" echo numpy==1.26.4
>> "%CONSTRAINTS%" echo transformers==4.49.0
>> "%CONSTRAINTS%" echo huggingface-hub^>=0.26.0^,<1.0
>> "%CONSTRAINTS%" echo torch==2.11.0+cu128
>> "%CONSTRAINTS%" echo torchvision==0.26.0+cu128
>> "%CONSTRAINTS%" echo torchaudio==2.11.0+cu128

echo.
echo Installing application dependencies while reusing the existing Torch installation...
echo Compatibility pins: NumPy 1.26.4, Transformers 4.49.0.
echo Downloaded packages may be reused from the local pip cache.
echo.

"%PY%" -m pip install --prefer-binary --disable-pip-version-check -c "%CONSTRAINTS%" -r "requirements.txt"
if errorlevel 1 goto :FAILED

echo.
echo Verifying the core application packages...
"%PY%" -c "import torch, numpy, scipy, gradio; from TTS.api import TTS; print('Torch:', torch.__version__); print('CUDA available:', torch.cuda.is_available()); print('NumPy:', numpy.__version__); print('SciPy:', scipy.__version__); print('Gradio:', gradio.__version__); print('Coqui TTS import: OK')"
if errorlevel 1 goto :FAILED

echo.
echo ===============================================
echo   INSTALLATION COMPLETED SUCCESSFULLY
echo ===============================================
echo You can now start the application with run.bat.
echo The existing .venv was kept; PyTorch was not reinstalled.
echo.
pause
exit /b 0

:FAILED
echo.
echo ===============================================
echo   INSTALLATION DID NOT COMPLETE
echo No command in this script deletes .venv or removes downloaded model/cache files.
echo Please save this window's error text and send it for inspection.
echo Do NOT rerun the old install.bat.
echo ===============================================
echo.
pause
exit /b 1
